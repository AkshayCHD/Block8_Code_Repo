exports.handler = async (event) => {
    const response = {
        status: 200,
        body: "Hello, World"
    }
    return response
}